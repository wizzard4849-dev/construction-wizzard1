'use client';

import { useMemo, useState } from 'react';

const trades = {
  drywall: { material: 0.65, labor: 1.75, unit: 'sq ft' },
  hvac: { material: 3.85, labor: 3.25, unit: 'sq ft' },
  flooring: { material: 2.9, labor: 1.95, unit: 'sq ft' },
  painting: { material: 0.95, labor: 1.35, unit: 'sq ft' },
} as const;

type View = 'dashboard' | 'estimator' | 'proposal' | 'bids';

function money(value: number) {
  return value.toLocaleString('en-CA', {
    style: 'currency',
    currency: 'CAD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });
}

export default function DemoPage() {
  const [view, setView] = useState<View>('dashboard');
  const [trade, setTrade] = useState<keyof typeof trades>('drywall');
  const [quantity, setQuantity] = useState(10000);
  const [waste, setWaste] = useState(8);
  const [overhead, setOverhead] = useState(12);
  const [profit, setProfit] = useState(18);
  const [lead, setLead] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    message: 'I want a 10-minute demo of Construction Wizzard.',
  });

  const estimate = useMemo(() => {
    const rates = trades[trade];
    const baseMaterial = quantity * rates.material;
    const wasteTotal = baseMaterial * (waste / 100);
    const materialTotal = baseMaterial + wasteTotal;
    const laborTotal = quantity * rates.labor;
    const subtotal = materialTotal + laborTotal;
    const overheadTotal = subtotal * (overhead / 100);
    const profitTotal = (subtotal + overheadTotal) * (profit / 100);
    const finalTotal = subtotal + overheadTotal + profitTotal;
    return { rates, materialTotal, laborTotal, overheadTotal, profitTotal, finalTotal };
  }, [trade, quantity, waste, overhead, profit]);

  return (
    <div className="page">
      <header className="header">
        <div className="container header-inner">
          <div className="brand">
            <div className="brand-mark">W</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 20 }}>Construction Wizzard</div>
              <div className="eyebrow">Estimating for Serious Builders</div>
            </div>
          </div>
          <div className="badge">Commercial • Residential • New Build</div>
        </div>
      </header>

      <main className="container">
        <section className="hero">
          <div>
            <span className="badge">Customer-facing sample presentation path</span>
            <h1 style={{ marginTop: 20 }}>
              Turn plans into <span style={{ color: '#fbbf24' }}>winning bids</span> in minutes.
            </h1>
            <p className="sub">
              Construction Wizzard helps serious builders create estimates, generate professional proposals, and track bids from draft to won without wasting hours in spreadsheets.
            </p>
            <div className="cta-row">
              <button className="btn btn-primary">Book a 10-minute demo</button>
              <button className="btn btn-secondary" onClick={() => setView('estimator')}>Watch sample flow</button>
            </div>
            <div className="grid-4">
              <div className="stat"><div className="label">Active Bids</div><div className="value">18</div></div>
              <div className="stat"><div className="label">Sent This Month</div><div className="value">11</div></div>
              <div className="stat"><div className="label">Won Revenue</div><div className="value">$185K</div></div>
              <div className="stat"><div className="label">Avg. Turnaround</div><div className="value">14 min</div></div>
            </div>
          </div>

          <div className="card">
            <div className="stack">
              <div>
                <div style={{ fontWeight: 800, fontSize: 24 }}>Live sample demo</div>
                <div className="muted" style={{ marginTop: 6 }}>Use this screen during sales calls or send it as a customer preview.</div>
              </div>

              <div className="demo-tabs">
                {(['dashboard', 'estimator', 'proposal', 'bids'] as View[]).map((tab) => (
                  <button key={tab} className={`tab ${view === tab ? 'active' : ''}`} onClick={() => setView(tab)}>
                    {tab[0].toUpperCase() + tab.slice(1)}
                  </button>
                ))}
              </div>

              {view === 'dashboard' && (
                <div className="stack">
                  <div className="mini-grid">
                    <div className="panel">
                      <div className="muted">Projected Revenue</div>
                      <div style={{ fontSize: 28, fontWeight: 800, marginTop: 10 }}>{money(estimate.finalTotal)}</div>
                    </div>
                    <div className="panel">
                      <div className="muted">Bid Pipeline</div>
                      <div style={{ fontSize: 28, fontWeight: 800, marginTop: 10 }}>Draft • Sent • Won</div>
                    </div>
                  </div>
                  <div className="panel">
                    <div style={{ fontWeight: 700, marginBottom: 10 }}>Why contractors care</div>
                    <div className="stack muted">
                      <div>• Faster estimates without Excel overload</div>
                      <div>• Clean, client-ready proposal generation</div>
                      <div>• Better follow-up on every job opportunity</div>
                    </div>
                  </div>
                </div>
              )}

              {view === 'estimator' && (
                <div className="stack">
                  <div className="mini-grid">
                    <label>
                      Trade
                      <select className="select" value={trade} onChange={(e) => setTrade(e.target.value as keyof typeof trades)}>
                        <option value="drywall">Drywall</option>
                        <option value="hvac">HVAC</option>
                        <option value="flooring">Flooring</option>
                        <option value="painting">Painting</option>
                      </select>
                    </label>
                    <label>
                      Quantity ({trades[trade].unit})
                      <input className="input" type="number" value={quantity} onChange={(e) => setQuantity(Number(e.target.value || 0))} />
                    </label>
                    <label>
                      Waste %
                      <input className="input" type="number" value={waste} onChange={(e) => setWaste(Number(e.target.value || 0))} />
                    </label>
                    <label>
                      Overhead %
                      <input className="input" type="number" value={overhead} onChange={(e) => setOverhead(Number(e.target.value || 0))} />
                    </label>
                  </div>
                  <div className="panel stack">
                    <div className="row"><span className="muted">Materials</span><span>{money(estimate.materialTotal)}</span></div>
                    <div className="row"><span className="muted">Labor</span><span>{money(estimate.laborTotal)}</span></div>
                    <div className="row"><span className="muted">Overhead</span><span>{money(estimate.overheadTotal)}</span></div>
                    <div className="row"><span className="muted">Profit</span><span>{money(estimate.profitTotal)}</span></div>
                    <div className="row" style={{ paddingTop: 10, borderTop: '1px solid rgba(255,255,255,0.1)', fontSize: 22, fontWeight: 800 }}>
                      <span>Final Bid</span>
                      <span style={{ color: '#fbbf24' }}>{money(estimate.finalTotal)}</span>
                    </div>
                  </div>
                </div>
              )}

              {view === 'proposal' && (
                <div className="white-sheet">
                  <div style={{ borderBottom: '1px solid #e4e4e7', paddingBottom: 16 }}>
                    <div style={{ fontWeight: 900, fontSize: 28 }}>Construction Wizzard</div>
                    <div className="muted">Estimating for Serious Builders</div>
                  </div>
                  <div className="stack" style={{ marginTop: 18 }}>
                    <div className="row"><span className="muted">Project</span><span>Commercial Tenant Fit-Out</span></div>
                    <div className="row"><span className="muted">Trade</span><span>{trade.toUpperCase()}</span></div>
                    <div className="row"><span className="muted">Timeline</span><span>2–4 weeks from mobilization</span></div>
                    <div style={{ lineHeight: 1.7, color: '#3f3f46' }}>
                      Scope includes labor, materials, and delivery for the requested work package, with proposal totals automatically calculated from your estimate.
                    </div>
                    <div style={{ textAlign: 'right', fontWeight: 900, fontSize: 28 }}>{money(estimate.finalTotal)}</div>
                  </div>
                </div>
              )}

              {view === 'bids' && (
                <div className="stack">
                  {[
                    ['Downtown Office Fit-Out', 'Sent', '$185,000'],
                    ['Maple Ridge Townhomes', 'Draft', '$94,000'],
                    ['Retail Flooring Package', 'Won', '$61,500'],
                  ].map(([title, status, value]) => (
                    <div key={title} className="panel row">
                      <div>
                        <div style={{ fontWeight: 700 }}>{title}</div>
                        <div className="muted" style={{ marginTop: 6 }}>Bid status tracking keeps every opportunity visible</div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <div className="muted">{status}</div>
                        <div style={{ fontWeight: 800, marginTop: 6 }}>{value}</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        <section className="section">
          <div className="eyebrow">Why it sells</div>
          <h2>A simple customer-facing presentation path</h2>
          <p className="sub">Use this exact flow during demos so contractors see the value quickly and understand why Construction Wizzard helps them bid more work.</p>
          <div className="cards-4">
            {[
              ['1. Show the estimate', 'Enter job size, trade, and markups. Let them watch the numbers update live.'],
              ['2. Show the proposal', 'Turn the estimate into a polished proposal they could send to a client the same day.'],
              ['3. Show delivery', 'Explain that the proposal can be exported as PDF and sent out quickly.'],
              ['4. Show bid tracking', 'Make it clear they can finally manage draft, sent, won, and lost jobs in one system.'],
            ].map(([title, text]) => (
              <div className="card" key={title}>
                <div className="icon-box">★</div>
                <div style={{ fontWeight: 800, fontSize: 20, marginTop: 16 }}>{title}</div>
                <div className="muted" style={{ marginTop: 10, lineHeight: 1.7 }}>{text}</div>
              </div>
            ))}
          </div>
        </section>

        <section className="section">
          <div className="cards-2">
            <div className="card">
              <div className="eyebrow" style={{ color: '#fcd34d' }}>The pitch</div>
              <h2 style={{ fontSize: 34 }}>What to say on the call</h2>
              <p className="sub">Keep it direct. Contractors care about speed, cleaner proposals, and more opportunities closed.</p>
              <div className="stack" style={{ marginTop: 20 }}>
                <div className="panel">“Are you still doing your estimates manually or in Excel?”</div>
                <div className="panel">“Construction Wizzard helps you create estimates and turn them into professional bids in minutes.”</div>
                <div className="panel">“If it helps you win even one more job a month, it pays for itself.”</div>
              </div>
            </div>

            <div className="card">
              <div className="eyebrow" style={{ color: '#fcd34d' }}>Book demos</div>
              <h2 style={{ fontSize: 34 }}>Customer-facing sample landing form</h2>
              <p className="sub">Use this form on your landing page or fill it out live during sales calls.</p>
              <div className="form-grid" style={{ marginTop: 20 }}>
                <label>
                  Name
                  <input className="input" value={lead.name} onChange={(e) => setLead({ ...lead, name: e.target.value })} placeholder="Anthony Wizzard" />
                </label>
                <label>
                  Company
                  <input className="input" value={lead.company} onChange={(e) => setLead({ ...lead, company: e.target.value })} placeholder="Serious Builders Inc." />
                </label>
                <label>
                  Email
                  <input className="input" value={lead.email} onChange={(e) => setLead({ ...lead, email: e.target.value })} placeholder="estimating@company.com" />
                </label>
                <label>
                  Phone
                  <input className="input" value={lead.phone} onChange={(e) => setLead({ ...lead, phone: e.target.value })} placeholder="416-555-0101" />
                </label>
              </div>
              <label style={{ marginTop: 14 }}>
                Message
                <textarea className="textarea" value={lead.message} onChange={(e) => setLead({ ...lead, message: e.target.value })} />
              </label>
              <div className="cta-row">
                <button className="btn btn-primary">Request Demo</button>
                <button className="btn btn-secondary">Download Sample Proposal</button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <div className="footer-note">Construction Wizzard customer demo page • Deploy on Vercel and send contractors to /demo</div>
    </div>
  );
}
